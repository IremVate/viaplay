package project.viaplay.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Links {
    @SerializedName("viaplay:sections")
    @Expose
    private ArrayList<SectionModel> sectionList;

    public ArrayList<SectionModel> getSectionList() {
        return sectionList;
    }

    public void setSectionList(ArrayList<SectionModel> sectionList) {
        this.sectionList = sectionList;
    }
}
