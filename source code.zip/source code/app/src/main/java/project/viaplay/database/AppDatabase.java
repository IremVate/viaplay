package project.viaplay.database;

import android.arch.persistence.db.SupportSQLiteOpenHelper;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.DatabaseConfiguration;
import android.arch.persistence.room.InvalidationTracker;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.support.annotation.NonNull;

import project.viaplay.database.dao.SectionDetailsDAO;
import project.viaplay.database.dao.SectionsDAO;
import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;

@Database(entities = {SectionModel.class, SectionDetailsModel.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase appDb;

    private static final String DB_NAME = "application_db";

    public static AppDatabase getAppDb(Context context) {
        if (appDb == null) {
            appDb = Room.databaseBuilder(context, AppDatabase.class, DB_NAME)
                    .fallbackToDestructiveMigration() //temporary
                    .allowMainThreadQueries() //temporary
                    .build();
        }
        return appDb;
    }

    public abstract SectionsDAO getSectionDAO();

    public abstract SectionDetailsDAO getSectionDetailsDAO();

}
