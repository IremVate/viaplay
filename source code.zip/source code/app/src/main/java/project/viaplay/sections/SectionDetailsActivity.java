package project.viaplay.sections;

import android.arch.lifecycle.Observer;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;

import project.viaplay.R;
import project.viaplay.databinding.ActivitySectionDetailsBinding;
import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;
import project.viaplay.viewmodels.SectionDetailsViewModel;

public class SectionDetailsActivity extends AppCompatActivity {

    private SectionModel sectionModel;

    private SectionDetailsViewModel sectionDetailsVM;

    private ActivitySectionDetailsBinding sectionDetailsBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sectionDetailsBinding = DataBindingUtil.setContentView(this, R.layout.activity_section_details);

        sectionDetailsVM = new SectionDetailsViewModel(this);

        sectionModel = getIntent() != null ? (SectionModel) getIntent().getParcelableExtra("sectionData") : new SectionModel();

        sectionDetailsVM.setCurrentSection(sectionModel);

        getSupportActionBar().setTitle(sectionModel.getTitle());

        sectionDetailsVM.callSectionDetails(sectionModel.getType() + "+" + sectionModel.getName());

        sectionDetailsBinding.textSectionDescription.setMovementMethod(new ScrollingMovementMethod());

        setData();
    }

    private void setData(){

        sectionDetailsVM.detailsMLD.observe(this, new Observer<SectionDetailsModel>() {
            @Override
            public void onChanged(@Nullable SectionDetailsModel sectionDetailsModel) {

                sectionDetailsBinding.textSectionTitle.setText(sectionDetailsModel.getTitle());

                sectionDetailsBinding.textSectionDescription.setText(sectionDetailsModel.getDescription());

            }
        });
    }
}
