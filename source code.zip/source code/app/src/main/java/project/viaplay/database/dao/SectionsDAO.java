package project.viaplay.database.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.ArrayList;
import java.util.List;

import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;

@Dao
public interface SectionsDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(SectionModel sectionModel);

    @Query("SELECT * FROM sections")
    List<SectionModel> getAllSections();

}
