package project.viaplay.models;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "details")
public class SectionDetailsModel implements Parcelable {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "detailsId")
    @SerializedName("sectionId")
    @Expose
    private String detailsId;

    @ColumnInfo(name = "detailsTitle")
    @SerializedName("title")
    @Expose
    private String title;

    @ColumnInfo(name = "description")
    @SerializedName("description")
    @Expose
    private String description;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDetailsId() {
        return detailsId;
    }

    public void setDetailsId(String detailsId) {
        this.detailsId = detailsId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.description);
    }

    public SectionDetailsModel() {
    }

    protected SectionDetailsModel(Parcel in) {
        this.title = in.readString();
        this.description = in.readString();
    }

    public static final Parcelable.Creator<SectionDetailsModel> CREATOR = new Parcelable.Creator<SectionDetailsModel>() {
        @Override
        public SectionDetailsModel createFromParcel(Parcel source) {
            return new SectionDetailsModel(source);
        }

        @Override
        public SectionDetailsModel[] newArray(int size) {
            return new SectionDetailsModel[size];
        }
    };
}
