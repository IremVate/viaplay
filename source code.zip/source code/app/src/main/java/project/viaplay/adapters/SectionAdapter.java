package project.viaplay.adapters;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

import project.viaplay.R;
import project.viaplay.databinding.ItemSectionBinding;
import project.viaplay.models.SectionModel;
import project.viaplay.sections.SectionDetailsActivity;

public class SectionAdapter  extends RecyclerView.Adapter<SectionAdapter.ViewHolder>{

    private Context context;

    private ArrayList<SectionModel> sectionList;

    private ItemSectionBinding sectionBinding;

    public SectionAdapter(Context context, ArrayList<SectionModel> sectionList) {
        this.context = context;
        this.sectionList = sectionList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        sectionBinding = DataBindingUtil.inflate(inflater, R.layout.item_section, parent, false);

        return new ViewHolder(sectionBinding.getRoot());
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ViewHolder viewHolder;

        viewHolder = holder;

        final SectionModel sectionModel = sectionList.get(position);

        sectionBinding.textSectionTitle.setText(sectionModel.getTitle());
        sectionBinding.textSectionName.setText(sectionModel.getName() + " - " + sectionModel.getType());

        sectionBinding.cardContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, SectionDetailsActivity.class);
                intent.putExtra("sectionData", sectionModel);
                context.startActivity(intent);
//                onItemClicked.onItemClicked();
            }
        });
    }

    @Override
    public int getItemCount() {
        return sectionList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvSectionTitle;
        private TextView tvSectionName;


        public ViewHolder(View itemView) {
            super(itemView);

            tvSectionTitle = itemView.findViewById(R.id.text_section_title);
            tvSectionName = itemView.findViewById(R.id.text_section_name);

        }
    }
}
