package project.viaplay.networking;

import project.viaplay.models.ResponseTemplateModel;
import project.viaplay.models.SectionDetailsModel;
import retrofit2.Call;
import retrofit2.http.GET;

public interface Service {
    @GET("androiddash-se")
    Call<ResponseTemplateModel> getSections();

    @GET("androiddash-se/serier")
    Call<SectionDetailsModel> getSerier();

    @GET("androiddash-se/film")
    Call<SectionDetailsModel> getFilm();

    @GET("androiddash-se/sport3")
    Call<SectionDetailsModel> getSport3();

    @GET("androiddash-se/sport2")
    Call<SectionDetailsModel> getSport2();

    @GET("androiddash-se/sport")
    Call<SectionDetailsModel> getSport();

    @GET("androiddash-se/barn")
    Call<SectionDetailsModel> getBarn();

    @GET("androiddash-se/store")
    Call<SectionDetailsModel> getStore();

}
