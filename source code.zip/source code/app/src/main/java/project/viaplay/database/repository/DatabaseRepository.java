package project.viaplay.database.repository;

import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

import project.viaplay.database.AppDatabase;
import project.viaplay.database.dao.SectionDetailsDAO;
import project.viaplay.database.dao.SectionsDAO;
import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;

public class DatabaseRepository {

    private SectionsDAO mSectionDao;

    private List<SectionModel> mAllSections;

    private SectionDetailsDAO mSectionDetailsDao;

    public DatabaseRepository(Context application) {
        AppDatabase db = AppDatabase.getAppDb(application);

        mSectionDao = db.getSectionDAO();
        mSectionDetailsDao = db.getSectionDetailsDAO();

        mAllSections = mSectionDao.getAllSections();
    }

    public List<SectionModel> getAllSections() {
        return mAllSections;
    }

    public SectionDetailsModel getSectionDetails(String id) {
        return mSectionDetailsDao.getSectionDetails(id);
    }

    public void insertSectionDetails(SectionDetailsModel sectionDetailsModel){
        new insertDetailsAsyncTask(mSectionDetailsDao).execute(sectionDetailsModel);
    }

    public void insertSection(SectionModel sectionModel) {
        new insertAsyncTask(mSectionDao).execute(sectionModel);
    }

    private static class insertAsyncTask extends AsyncTask<SectionModel, Void, Void> {

        private SectionsDAO mAsyncTaskDao;

        insertAsyncTask(SectionsDAO dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final SectionModel... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    private static class insertDetailsAsyncTask extends AsyncTask<SectionDetailsModel, Void, Void> {

        private SectionDetailsDAO mAsyncTaskDao;

        insertDetailsAsyncTask(SectionDetailsDAO dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final SectionDetailsModel... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }
}
