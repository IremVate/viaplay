package project.viaplay.viewmodels;

import android.app.Application;
import android.app.ProgressDialog;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import java.util.ArrayList;

import project.viaplay.R;
import project.viaplay.database.AppDatabase;
import project.viaplay.database.repository.DatabaseRepository;
import project.viaplay.models.ResponseTemplateModel;
import project.viaplay.models.SectionModel;
import project.viaplay.networking.CustomCallBack;
import project.viaplay.networking.NetworkSDK;
import project.viaplay.utils.AppUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SectionViewModel {

    private Context context;

    private DatabaseRepository repository;

    public MutableLiveData<ArrayList<SectionModel>> sectionMLD = new MutableLiveData<>();

    public SectionViewModel(Context context) {
        this.context = context;

        repository = new DatabaseRepository(context);

        getSections();
    }

    public void getSections() {

        NetworkSDK.getInstance().getSections(new CustomCallBack<ResponseTemplateModel>(context) {
            @Override
            public void onResponse(Call<ResponseTemplateModel> call, Response<ResponseTemplateModel> response) {
                super.onResponse(call, response);
                if(response.isSuccessful()){
                    sectionMLD.postValue(response.body().getLinks().getSectionList());

                    insertSections(response.body().getLinks().getSectionList());
                }
            }

            @Override
            public void onFailure(Call<ResponseTemplateModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getAllSections() != null && repository.getAllSections().size() > 0){
                    sectionMLD.postValue((ArrayList<SectionModel>) repository.getAllSections());

                }
                else {

                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void insertSections(ArrayList<SectionModel> sectionModels){
        for(SectionModel sectionModel : sectionModels){
            repository.insertSection(sectionModel);
        }
    }

}
