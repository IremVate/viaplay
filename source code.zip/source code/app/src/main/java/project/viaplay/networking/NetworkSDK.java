package project.viaplay.networking;

import project.viaplay.models.ResponseTemplateModel;
import project.viaplay.models.SectionDetailsModel;
import retrofit2.Call;

public class NetworkSDK {

    public static NetworkSDK instance;

    public static NetworkSDK getInstance() {
        if (instance == null) {
            instance = new NetworkSDK();
        }
        return instance;
    }

    public void getSections(CustomCallBack<ResponseTemplateModel> callback) {
        Call<ResponseTemplateModel> call = BaseClient.getService().getSections();
        call.enqueue(callback);
    }

    public void getSerier(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getSerier();
        call.enqueue(callback);
    }

    public void getFilm(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getFilm();
        call.enqueue(callback);
    }

    public void getSport3(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getSport3();
        call.enqueue(callback);
    }

    public void getSport2(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getSport2();
        call.enqueue(callback);
    }

    public void getSport(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getSport();
        call.enqueue(callback);
    }

    public void getBarn(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getBarn();
        call.enqueue(callback);
    }

    public void getStore(CustomCallBack<SectionDetailsModel> callback) {
        Call<SectionDetailsModel> call = BaseClient.getService().getStore();
        call.enqueue(callback);
    }

}