package project.viaplay;

import android.arch.lifecycle.Observer;
import android.databinding.DataBindingUtil;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;

import java.util.ArrayList;

import project.viaplay.adapters.SectionAdapter;
import project.viaplay.databinding.ActivityMainBinding;
import project.viaplay.models.SectionModel;
import project.viaplay.viewmodels.SectionViewModel;

public class MainActivity extends AppCompatActivity {

    private SectionAdapter adapter;

    private SectionViewModel sectionVM;

    private ActivityMainBinding activityMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setTitle(getResources().getString(R.string.section_title));

        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        sectionVM = new SectionViewModel(this);

        getData();
    }

    private void getData(){

        sectionVM.sectionMLD.observe(this, new Observer<ArrayList<SectionModel>>() {
            @Override
            public void onChanged(@Nullable ArrayList<SectionModel> sectionModels) {

                adapter = new SectionAdapter(MainActivity.this, sectionModels);

                activityMainBinding.recyclerViewSections.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));

                activityMainBinding.recyclerViewSections.setAdapter(adapter);
            }
        });

    }
}
