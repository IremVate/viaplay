package project.viaplay.database.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;

@Dao
public interface SectionDetailsDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(SectionDetailsModel sectionModel);

    @Query("SELECT * FROM details WHERE detailsId =:id LIMIT 1")
    SectionDetailsModel getSectionDetails(final String id);

}
