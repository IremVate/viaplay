package project.viaplay.viewmodels;

import android.arch.lifecycle.MutableLiveData;
import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.widget.Toast;

import project.viaplay.BR;
import project.viaplay.R;
import project.viaplay.database.repository.DatabaseRepository;
import project.viaplay.models.SectionDetailsModel;
import project.viaplay.models.SectionModel;
import project.viaplay.networking.CustomCallBack;
import project.viaplay.networking.NetworkSDK;
import project.viaplay.utils.AppUtils;
import retrofit2.Call;
import retrofit2.Response;

public class SectionDetailsViewModel extends BaseObservable {

    private Context context;

    private SectionModel currentSection;

    private DatabaseRepository repository;

    public MutableLiveData<SectionDetailsModel> detailsMLD = new MutableLiveData<>();

    public SectionDetailsViewModel(Context context) {
        this.context = context;

        repository = new DatabaseRepository(context);
    }

    @Bindable
    public SectionModel getCurrentSection() {
        return currentSection;
    }

    public void setCurrentSection(SectionModel currentSection) {
        this.currentSection = currentSection;
        notifyPropertyChanged(BR.currentSection);
    }

    public void callSectionDetails(String type){
        switch(type){

             case "vod+series":
                 getSerier();
                break;
            case "vod+movie":
                getFilm();
                break;
            case "sport+sport":
                getSport3();
                break;
            case "sportPerDay+sport":
                getSport2();
                break;
            case "vod+sport":
                getSport();
                break;
            case "vod+kids":
                getBarn();
                break;
            case "tvod+rental":
                getStore();
                break;
        }
    }

    private void getSerier(){

        NetworkSDK.getInstance().getSerier(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);
                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());
                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {
                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void getFilm(){
        NetworkSDK.getInstance().getFilm(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);
                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());
                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {

                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void getSport3(){
        NetworkSDK.getInstance().getSport3(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);

                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());
                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {

                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    private void getSport2(){
        NetworkSDK.getInstance().getSport2(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);

                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());

                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {
                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getSport(){
        NetworkSDK.getInstance().getSport(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);

                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());

                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {
                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void getBarn(){
        NetworkSDK.getInstance().getBarn(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);

                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());

                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {
                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void getStore(){
        NetworkSDK.getInstance().getStore(new CustomCallBack<SectionDetailsModel>(context) {

            @Override
            public void onResponse(Call<SectionDetailsModel> call, Response<SectionDetailsModel> response) {
                super.onResponse(call, response);

                if(response.isSuccessful()){
                    detailsMLD.postValue(response.body());

                    repository.insertSectionDetails(response.body());

                }
            }

            @Override
            public void onFailure(Call<SectionDetailsModel> call, Throwable t) {
                super.onFailure(call, t);

                if(repository.getSectionDetails(currentSection.getId()) != null){
                    detailsMLD.postValue(repository.getSectionDetails(currentSection.getId()));
                }
                else {
                    Toast.makeText(context, context.getResources().getString(R.string.error_something_wrong), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
