package project.viaplay.networking;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class BaseClient {

    public  static Retrofit client;
    public  static Service  service;
    public  static String BASE_URL = "https://content.viaplay.se/";

    private static Retrofit getClient(){

        if(client == null){

            OkHttpClient okHttpClient = new OkHttpClient.Builder().addInterceptor(new HeaderInterceptor()).addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)).build();

            client = new Retrofit.Builder().
                    baseUrl(BASE_URL).
                    addConverterFactory(GsonConverterFactory.create()).
                    client(okHttpClient).
                    build();

        }
        return client;
    }

    public static Service getService(){
        if(service == null){
            service = getClient().create(Service.class);
        }
        return service;
    }
}

